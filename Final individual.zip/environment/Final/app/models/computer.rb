class Computer < ApplicationRecord
end
